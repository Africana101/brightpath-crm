# BrightPath Learning CRM

Static CRM prototype based on the BrightPath Learning CRM User Stories document.

## Deploy to Vercel through GitHub

1. Create a new GitHub repository, e.g. `brightpath-crm`.
2. Upload `index.html` and `README.md` to the repository root.
3. In Vercel choose **Add New → Project**.
4. Import the GitHub repository.
5. Framework Preset: **Other** (or leave the detected static setting).
6. Build Command: leave blank.
7. Output Directory: leave blank.
8. Click **Deploy**.

This is a front-end prototype. The buttons and workflows demonstrate the CRM requirements, but production data persistence, authentication, APIs, LMS/payment integrations and real email/SMS sending would require a backend/integration layer.
